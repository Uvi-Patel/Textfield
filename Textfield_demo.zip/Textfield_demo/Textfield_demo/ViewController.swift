//
//  ViewController.swift
//  Textfield_demo
//
//  Created by MAC on 01/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var lb: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        UITextField.appearance().tintColor = UIColor.black
        let mytextfield = UITextField()
        mytextfield.frame = CGRect(x: 40, y: 200, width: 300, height: 30)
        //mytextfield.center = self.view.center
        //mytextfield.placeholder = "Enter your name"
        mytextfield.attributedPlaceholder = NSAttributedString(string: "enter your name", attributes: [NSAttributedString.Key.foregroundColor: UIColor.blue])
       // mytextfield.text = "hii"
        let rightView = UIView(frame: CGRect(x: 0, y: 0, width: 30, height: 30))
            mytextfield.rightViewMode = UITextField.ViewMode.always
            mytextfield.rightView = rightView
        let leftView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
            mytextfield.leftViewMode = UITextField.ViewMode.always
            mytextfield.leftView = leftView
        mytextfield.font = UIFont.italicSystemFont(ofSize: 20)
        mytextfield.autocorrectionType = UITextAutocorrectionType.yes
        mytextfield.keyboardType = UIKeyboardType.default
        mytextfield.returnKeyType = UIReturnKeyType.default
        mytextfield.clearButtonMode = UITextField.ViewMode.whileEditing
        mytextfield.contentVerticalAlignment = UIControl.ContentVerticalAlignment.center
        mytextfield.delegate = self
        mytextfield.tag = 0
        mytextfield.borderStyle = UITextField.BorderStyle.line
        mytextfield.backgroundColor = UIColor.cyan
        mytextfield.textColor = UIColor.black
        self.view.addSubview(mytextfield)
        
        let mytextfield2 = UITextField()
        mytextfield2.frame = CGRect(x: 40, y: 250, width: 300, height: 30)
        mytextfield2.backgroundColor = UIColor.cyan
        mytextfield2.delegate = self
        mytextfield2.tag = 1
        self.view.addSubview(mytextfield2)
        
        let mytextfield3 = UITextField()
        mytextfield3.frame = CGRect(x: 40, y: 300, width: 300, height: 30)
        mytextfield3.delegate = self
        mytextfield3.tag = 2
        mytextfield3.isSecureTextEntry = true //password
        mytextfield3.backgroundColor = UIColor.cyan
        mytextfield3.placeholder = "Enter Password"
        
        mytextfield3.rightViewMode = UITextField.ViewMode.always
        let imageView = UIImageView()
        imageView.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
        imageView.contentMode = .scaleAspectFit
        
        let rightVeiwView = UIView(frame: CGRect(x: 10, y: 0, width: 40, height: 40))
        mytextfield3.rightView = rightVeiwView
        mytextfield3.rightViewMode = .always
        let iconImage = UIImageView(frame: CGRect(x: 10, y: 5, width: 30, height: 30))
        iconImage.image = UIImage(named: "aa")
        rightVeiwView.addSubview(iconImage)
        
        self.view.addSubview(mytextfield3)

        // Do any additional setup after loading the view.
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
       // Try to find next responder
        
       if let nextField = textField.superview?.viewWithTag(textField.tag + 1) as? UITextField {
          nextField.becomeFirstResponder()
       }
       else {
        
          // Not found, so remove keyboard.
          textField.resignFirstResponder()
       }
        
        // Do not add a line break
       return false
    }
//    @objc func textFieldShouldBeginEditing(_ mytextfield: UITextField) -> Bool {
//        mytextfield.backgroundColor = UIColor.yellow
//        return true
//    }
//     func textRect(forBounds bounds: CGRect) -> CGRect {
//        return bounds.insetBy(dx: 100, dy: 0)
//    }
//     func editingRect(forBounds bounds: CGRect) -> CGRect {
//        return CGRect(x: bounds.origin.x + 16, y: bounds.origin.y, width: bounds.width - 56, height: bounds.height)
//    }
//     func clearButtonRect(forBounds bounds: CGRect) -> CGRect {
//        return CGRect(x: bounds.width - 36, y: bounds.origin.y, width: 16, height: bounds.height)
//    }
//     func draw(_ mytextfield: CGRect) {
//          let inset = UIEdgeInsets(top: -2, left: 2, bottom: -2, right: 2)
//    }
    func  textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        print("textFieldShouldBeginEditing")
        return true
    }
    
    func textFieldDidBeginEditing(_ mytextfield: UITextField) {
           
           // While selecting the text field
        //view.backgroundColor = UIColor.purple
        print("textFieldDidBeginEditing")
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        print("textFieldShouldEndEditing")
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        print("textFieldDidEndEditing")
    }
    
    func textFieldDidChangeSelection(_ textField: UITextField) {
        print("textFieldDidChangeSelection")
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        print("textfield")
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        print("textFieldShouldClear")
        return true
    }
    
   /* func textFieldShouldReturn(_ mytextfield: UITextField) -> Bool {
    
        //Display the result.
        lb.text = "hello " + mytextfield.text!
        print("textFieldShouldReturn")
       // view.backgroundColor = UIColor.orange
        return true
    }*/
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
       
        // While touching outside the textField.
        //view.backgroundColor = UIColor.cyan
        print("touchesBegan")
    }

}

